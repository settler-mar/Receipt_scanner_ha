from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import accounts, dashboard, oauth, receipts, stores
from app.core.config import settings
from app.db import Base, engine
from app.models import models  # noqa: F401 — registers tables on Base.metadata
from app.scheduler import start_scheduler
from app.seed import seed_stores


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    seed_stores()
    start_scheduler()
    yield


app = FastAPI(title="Receipt Scanner", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(stores.router)
app.include_router(accounts.router)
app.include_router(receipts.router)
app.include_router(dashboard.router)
app.include_router(oauth.router)


@app.get("/api/health")
def health():
    return {"status": "ok"}
