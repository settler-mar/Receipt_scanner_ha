"""SQLite doesn't persist tzinfo on DateTime(timezone=True) columns — values come
back naive even though everything is written/compared as UTC. Every value read
from the DB and compared against a fresh `datetime.now(timezone.utc)` needs this.
"""
from __future__ import annotations

import datetime as dt


def as_utc(value: dt.datetime | None) -> dt.datetime | None:
    if value is not None and value.tzinfo is None:
        return value.replace(tzinfo=dt.timezone.utc)
    return value
