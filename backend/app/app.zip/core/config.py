from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=BASE_DIR / ".env", env_prefix="RS_")

    database_url: str = f"sqlite:///{BASE_DIR / 'data' / 'receipts.db'}"
    # Fernet key for encrypting stored tokens at rest. Generate with:
    #   python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
    secret_key: str = "CHANGE_ME_dev_only_insecure_key_______________="
    cors_origins: list[str] = ["http://localhost:5173"]
    # This backend's own externally-reachable base URL — used to build OAuth
    # redirect_uri values (silpo.py). Must exactly match what's registered with
    # the provider's Dynamic Client Registration (see adapters/silpo.py).
    base_url: str = "http://192.168.1.170:8001"


settings = Settings()
(BASE_DIR / "data").mkdir(exist_ok=True)
