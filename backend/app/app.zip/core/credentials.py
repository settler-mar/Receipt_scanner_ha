"""Shared helper to persist an adapter's AuthResult onto an Account's Credential —
used by the phone/OTP login endpoints and the OAuth-browser callback alike."""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.adapters.base import AuthResult
from app.core.security import encrypt
from app.models.models import Account, Credential


def upsert_credential(db: Session, account: Account, result: AuthResult) -> None:
    cred = account.credential or Credential(account_id=account.id)
    if result.access_token is not None:
        cred.access_token_enc = encrypt(result.access_token)
    if result.refresh_token is not None:
        cred.refresh_token_enc = encrypt(result.refresh_token)
    if result.expires_at is not None:
        cred.expires_at = result.expires_at
    cred.extra = {**(cred.extra or {}), **result.extra}
    if account.credential is None:
        db.add(cred)
