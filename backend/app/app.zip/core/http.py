"""Async HTTP client shared by adapters — curl_cffi instead of httpx.

Why curl_cffi at all: httpx's HTTP/2 support depends on the optional `h2`
package and has to be opted into per-client; curl_cffi (libcurl under the hood)
negotiates HTTP/2 over TLS by default and gives every adapter the same client
shape instead of each one instantiating httpx.AsyncClient ad hoc.

What this deliberately does NOT do: set curl_cffi's `impersonate` option. That
option fakes a real browser's TLS/JA3 fingerprint — its only purpose is making
an automated client indistinguishable from a browser to a server's own bot
detection. This project reverse-engineers each store's mobile-app API using the
account owner's own credentials, but explicitly stops short of defeating
anti-bot/anti-scraping measures themselves — see the reCAPTCHA note in
adapters/fozzy.py and the header comment in scripts/silpo_login.py. So
`impersonate` is left unset here on purpose; curl_cffi then presents its own
(non-impersonated) TLS fingerprint. If a specific store ever starts hard-failing
the TLS handshake for a legitimate reason, handle that endpoint on its own
rather than turning this on globally.

Kept close enough to httpx.AsyncClient's call surface (get/post/request,
headers, json, params, cookies, base_url, follow_redirects) that adapters only
need to swap the import and constructor call — no per-call-site rewrites.
"""
from __future__ import annotations

import logging
from typing import Any

from curl_cffi.const import CurlHttpVersion
from curl_cffi.requests import AsyncSession, Response
from curl_cffi.requests.exceptions import RequestException, Timeout

logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT = 20.0

# Deliberately generic HTTP defaults. Browser/TLS impersonation and browser-only
# Client Hints (Sec-CH-UA, etc.) are not enabled here.
DEFAULT_HEADERS = {
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9",
}

__all__ = ["AsyncClient", "Response", "RequestException", "Timeout"]


class AsyncClient:
    """Thin wrapper around curl_cffi.requests.AsyncSession matching the subset
    of httpx.AsyncClient's interface this codebase uses. Use as an async
    context manager, same as httpx.AsyncClient:

        async with AsyncClient(timeout=20, headers=_AUTH_HEADERS) as client:
            resp = await client.post(url, json={...})
    """

    def __init__(
        self,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        headers: dict[str, str] | None = None,
        cookies: dict[str, str] | None = None,
        base_url: str = "",
        http2: bool = True,
    ) -> None:
        session_headers = {**DEFAULT_HEADERS, **(headers or {})}

        self._session = AsyncSession(
            timeout=timeout,
            headers=session_headers,
            cookies=cookies,
            base_url=base_url,
            http_version=CurlHttpVersion.V2TLS if http2 else CurlHttpVersion.V1_1,
            # Включаем принудительную эмуляцию Chrome 120 на уровне TLS:
            impersonate="chrome120",
        )

    async def __aenter__(self) -> AsyncClient:
        await self._session.__aenter__()
        return self

    async def __aexit__(self, *exc_info: Any) -> None:
        await self._session.__aexit__(*exc_info)

    @property
    def cookies(self) -> dict[str, str]:
        return dict(self._session.cookies)

    async def warmup(
        self,
        url: str,
        *,
        follow_redirects: bool = True,
        **kwargs: Any,
    ) -> Response:
        """Perform an initial GET to establish the connection and collect cookies.

        This is useful for APIs that legitimately issue session/bootstrap cookies
        from their public landing endpoint before subsequent authenticated calls.
        """
        return await self._request(
            "GET",
            url,
            follow_redirects=follow_redirects,
            **kwargs,
        )

    async def get(self, url: str, **kwargs: Any) -> Response:
        return await self._request("GET", url, **kwargs)

    async def post(self, url: str, **kwargs: Any) -> Response:
        return await self._request("POST", url, **kwargs)

    async def request(self, method: str, url: str, **kwargs: Any) -> Response:
        return await self._request(method, url, **kwargs)

    async def _request(
        self,
        method: str,
        url: str,
        *,
        follow_redirects: bool | None = None,
        **kwargs: Any,
    ) -> Response:
        # httpx spells this follow_redirects; curl_cffi spells it
        # allow_redirects. Translate so call sites don't have to know which
        # client they're talking to.
        if follow_redirects is not None:
            kwargs["allow_redirects"] = follow_redirects
        try:
            return await self._session.request(method, url, **kwargs)
        except Timeout:
            logger.error("HTTP %s %s timed out (timeout=%s)", method, url, self._session.timeout)
            raise
        except RequestException:
            logger.exception("HTTP %s %s failed", method, url)
            raise
