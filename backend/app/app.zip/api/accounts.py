from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

import secrets

from app.adapters.base import AdapterError
from app.adapters.registry import get_adapter
from app.api.deps import get_account_or_404, get_db
from app.core import oauth_state
from app.core.config import settings
from app.core.credentials import upsert_credential
from app.core.pkce import pkce_pair
from app.core.security import decrypt, encrypt
from app.models.models import (
    Account,
    AccountStatus,
    CollectionRun,
    Credential,
    Receipt,
    RunStatus,
    Schedule,
    Store,
)
from app.schemas.schemas import (
    AccountCreate,
    AccountOut,
    ImportPayload,
    LoginConfirm,
    LoginStart,
    LoyaltyCodeOut,
    RunOut,
    ScheduleUpdate,
    TokenBootstrap,
)
from app.services.collector import collect_for_account, ensure_fresh_token, import_for_account

router = APIRouter(prefix="/api/accounts", tags=["accounts"])


def _to_out(db: Session, account: Account) -> AccountOut:
    count = db.execute(
        select(func.count()).select_from(Receipt).where(Receipt.account_id == account.id)
    ).scalar_one()
    last_collected_at = db.execute(
        select(func.max(CollectionRun.finished_at)).where(
            CollectionRun.account_id == account.id, CollectionRun.status == RunStatus.success
        )
    ).scalar_one()
    out = AccountOut.model_validate(account)
    out.receipt_count = count
    out.last_collected_at = last_collected_at
    return out


@router.get("", response_model=list[AccountOut])
def list_accounts(db: Session = Depends(get_db)):
    accounts = db.execute(select(Account)).scalars().all()
    return [_to_out(db, a) for a in accounts]


@router.post("", response_model=AccountOut, status_code=201)
def create_account(payload: AccountCreate, db: Session = Depends(get_db)):
    store = db.execute(select(Store).where(Store.code == payload.store_code)).scalar_one_or_none()
    if store is None:
        raise HTTPException(status_code=400, detail=f"Unknown store code: {payload.store_code}")

    account = Account(
        store_id=store.id,
        label=payload.label,
        phone_number=payload.phone_number,
        status=AccountStatus.pending_otp,
    )
    db.add(account)
    db.flush()
    db.add(Schedule(account_id=account.id))
    db.commit()
    db.refresh(account)
    return _to_out(db, account)


@router.delete("/{account_id}", status_code=204)
def delete_account(account: Account = Depends(get_account_or_404), db: Session = Depends(get_db)):
    db.delete(account)
    db.commit()


@router.post("/{account_id}/login/start")
async def login_start(account: Account = Depends(get_account_or_404), db: Session = Depends(get_db)):
    if not account.phone_number:
        raise HTTPException(status_code=400, detail="У акаунта не вказано номер телефону")
    adapter = get_adapter(account.store.code)
    try:
        result = await adapter.start_login(account.phone_number)
    except AdapterError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    upsert_credential(db, account, result)
    account.status = AccountStatus.pending_otp
    db.commit()
    return {"pending": result.pending}


@router.post("/{account_id}/login/confirm")
async def login_confirm(
    payload: LoginConfirm,
    account: Account = Depends(get_account_or_404),
    db: Session = Depends(get_db),
):
    adapter = get_adapter(account.store.code)
    extra = dict(account.credential.extra) if account.credential else {}
    try:
        result = await adapter.confirm_login(extra, payload.code)
    except AdapterError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    upsert_credential(db, account, result)
    account.status = AccountStatus.active
    account.last_error = None
    db.commit()
    return {"status": "active"}


@router.get("/{account_id}/oauth/start")
def oauth_start(account: Account = Depends(get_account_or_404)):
    """For AuthType.oauth_browser stores (silpo): kicks off an OAuth 2.1 + PKCE
    login. Returns a URL for the frontend to open in a new tab; the provider
    redirects the user's browser to /api/oauth/{store_code}/callback (see
    app/api/oauth.py) once they finish logging in there."""
    adapter = get_adapter(account.store.code)
    verifier, challenge = pkce_pair()
    state = secrets.token_urlsafe(24)
    redirect_uri = f"{settings.base_url}/api/oauth/{account.store.code}/callback"
    try:
        url = adapter.oauth_authorize_url(state=state, redirect_uri=redirect_uri, code_challenge=challenge)
    except AdapterError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    oauth_state.put(state, {"account_id": account.id, "verifier": verifier, "redirect_uri": redirect_uri})
    return {"authorize_url": url}


@router.post("/{account_id}/logout", response_model=AccountOut)
def logout(account: Account = Depends(get_account_or_404), db: Session = Depends(get_db)):
    """Clears the stored credential so the account can be re-authenticated from
    scratch (SMS or manual token). Receipts already collected are kept."""
    if account.credential is not None:
        db.delete(account.credential)
    account.status = AccountStatus.pending_otp
    account.last_error = None
    db.commit()
    db.refresh(account)
    return _to_out(db, account)


@router.post("/{account_id}/token", response_model=AccountOut)
def bootstrap_token(
    payload: TokenBootstrap,
    account: Account = Depends(get_account_or_404),
    db: Session = Depends(get_db),
):
    """Manual escape hatch: paste in a token captured via mitmproxy, until real
    OTP automation exists for this store (see adapters/*.py docstrings)."""
    cred = account.credential or Credential(account_id=account.id)
    cred.access_token_enc = encrypt(payload.access_token)
    cred.refresh_token_enc = encrypt(payload.refresh_token)
    cred.expires_at = payload.expires_at
    cred.extra = {**(cred.extra or {}), **payload.extra}
    if account.credential is None:
        db.add(cred)
    account.status = AccountStatus.active
    account.last_error = None
    db.commit()
    db.refresh(account)
    return _to_out(db, account)


@router.put("/{account_id}/schedule")
def update_schedule(
    payload: ScheduleUpdate,
    account: Account = Depends(get_account_or_404),
    db: Session = Depends(get_db),
):
    schedule = account.schedule or Schedule(account_id=account.id)
    if payload.enabled is not None:
        schedule.enabled = payload.enabled
    if payload.cron_expression is not None:
        schedule.cron_expression = payload.cron_expression
    if account.schedule is None:
        db.add(schedule)
    db.commit()
    return {"status": "ok"}


@router.post("/{account_id}/collect", response_model=RunOut)
async def collect_now(account: Account = Depends(get_account_or_404), db: Session = Depends(get_db)):
    run = await collect_for_account(db, account, trigger="manual")
    return run


@router.post("/{account_id}/import", response_model=RunOut)
def import_receipts(
    body: ImportPayload,
    account: Account = Depends(get_account_or_404),
    db: Session = Depends(get_db),
):
    """Paste a raw API response captured via mitmproxy — for stores where live
    collection is blocked (e.g. АТБ, see RESEARCH.md)."""
    try:
        run = import_for_account(db, account, body.payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return run


@router.get("/{account_id}/loyalty-code", response_model=LoyaltyCodeOut)
async def loyalty_code(account: Account = Depends(get_account_or_404), db: Session = Depends(get_db)):
    """Fetched live on every call, not cached — some stores (АТБ) issue a
    short-lived rotating code. Not every store supports this (see adapters/*.py)."""
    if account.credential is None or not account.credential.access_token_enc:
        raise HTTPException(status_code=400, detail="Немає токена — спершу пройдіть авторизацію")
    adapter = get_adapter(account.store.code)
    try:
        access_token = await ensure_fresh_token(db, account, adapter)
        code = await adapter.get_loyalty_code(access_token, dict(account.credential.extra or {}))
    except AdapterError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return LoyaltyCodeOut(value=code.value, display=code.display, expires_at=code.expires_at)


@router.get("/{account_id}/runs", response_model=list[RunOut])
def list_runs(account: Account = Depends(get_account_or_404), db: Session = Depends(get_db)):
    return db.execute(
        select(CollectionRun)
        .where(CollectionRun.account_id == account.id)
        .order_by(CollectionRun.started_at.desc())
        .limit(50)
    ).scalars().all()
