from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.db import get_db
from app.models.models import Account, AccountStatus, CollectionRun, Receipt
from app.schemas.schemas import DashboardStats

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("", response_model=DashboardStats)
def get_stats(db: Session = Depends(get_db)):
    total_receipts = db.execute(select(func.count()).select_from(Receipt)).scalar_one()
    total_spent = db.execute(select(func.coalesce(func.sum(Receipt.total_amount), 0))).scalar_one()
    total_discount = db.execute(select(func.coalesce(func.sum(Receipt.total_discount), 0))).scalar_one()
    total_bonuses = db.execute(select(func.coalesce(func.sum(Receipt.bonuses), 0))).scalar_one()
    total_bonuses_used = db.execute(select(func.coalesce(func.sum(Receipt.bonuses_used), 0))).scalar_one()
    active = db.execute(
        select(func.count()).select_from(Account).where(Account.status == AccountStatus.active)
    ).scalar_one()
    needs_attention = db.execute(
        select(func.count())
        .select_from(Account)
        .where(Account.status.in_([AccountStatus.needs_reauth, AccountStatus.error]))
    ).scalar_one()
    last_run = db.execute(select(func.max(CollectionRun.started_at))).scalar_one()

    return DashboardStats(
        total_receipts=total_receipts,
        total_spent=float(total_spent),
        total_discount=float(total_discount),
        total_bonuses=float(total_bonuses),
        total_bonuses_used=float(total_bonuses_used),
        accounts_active=active,
        accounts_needs_attention=needs_attention,
        last_run_at=last_run,
    )
