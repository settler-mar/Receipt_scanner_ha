from __future__ import annotations

import datetime as dt

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from app.db import get_db
from app.models.models import Account, Receipt
from app.schemas.schemas import ReceiptListOut, ReceiptOut

router = APIRouter(prefix="/api/receipts", tags=["receipts"])


@router.get("", response_model=ReceiptListOut)
def list_receipts(
    db: Session = Depends(get_db),
    store_code: str | None = None,
    account_id: str | None = None,
    channel: str | None = None,
    date_from: dt.datetime | None = None,
    date_to: dt.datetime | None = None,
    search: str | None = Query(default=None, description="Free-text over shop name / item names"),
    limit: int = Query(default=50, le=200),
    offset: int = 0,
):
    stmt = select(Receipt).options(selectinload(Receipt.items), selectinload(Receipt.account))
    if store_code:
        stmt = stmt.where(Receipt.store_code == store_code)
    if account_id:
        stmt = stmt.where(Receipt.account_id == account_id)
    if channel:
        stmt = stmt.where(Receipt.channel == channel)
    if date_from:
        stmt = stmt.where(Receipt.purchased_at >= date_from)
    if date_to:
        stmt = stmt.where(Receipt.purchased_at <= date_to)
    if search:
        stmt = stmt.where(Receipt.shop_name.ilike(f"%{search}%"))

    total = db.execute(select(func.count()).select_from(stmt.subquery())).scalar_one()
    rows = db.execute(
        stmt.order_by(Receipt.purchased_at.desc()).limit(limit).offset(offset)
    ).scalars().all()

    items = []
    for r in rows:
        out = ReceiptOut.model_validate(r)
        out.account_label = r.account.label
        items.append(out)

    return ReceiptListOut(total=total, items=items)


@router.get("/{receipt_id}", response_model=ReceiptOut)
def get_receipt(receipt_id: str, db: Session = Depends(get_db)):
    r = db.get(Receipt, receipt_id, options=[selectinload(Receipt.items), selectinload(Receipt.account)])
    if r is None:
        raise HTTPException(status_code=404, detail="Receipt not found")
    out = ReceiptOut.model_validate(r)
    out.account_label = r.account.label
    return out
