"""Common contract every store adapter implements.

An adapter knows how to: (1) log an account in via phone+SMS (where applicable),
(2) refresh an expired token, and (3) pull the list of receipts + their line items,
translating the store's own response shape into the normalized dataclasses below.

Nothing here talks to the database — adapters are pure API clients. The collector
service (app/services/collector.py) is what persists NormalizedReceipt -> Receipt rows.
"""
from __future__ import annotations

import abc
import dataclasses
import datetime as dt


@dataclasses.dataclass
class NormalizedItem:
    name: str
    total_price: float
    quantity: float = 1
    unit: str | None = None
    unit_price: float | None = None
    barcode: str | None = None
    category: str | None = None
    discount: float = 0


@dataclasses.dataclass
class NormalizedReceipt:
    external_id: str
    purchased_at: dt.datetime
    total_amount: float
    currency: str = "UAH"
    shop_name: str | None = None
    shop_address: str | None = None
    payment_type: str | None = None
    # "offline" (in-store/till) or "online" (delivery/pickup order). Every adapter
    # defaults to "offline" since that's the only channel most stores expose;
    # Fora is the one store so far with a genuine online branch (see fora.py).
    channel: str = "offline"
    items: list[NormalizedItem] = dataclasses.field(default_factory=list)
    raw: dict = dataclasses.field(default_factory=dict)
    # Override for the receipt-level discount total. Leave None to have the
    # collector sum item discounts instead — set this when the store's API gives
    # an authoritative total directly but doesn't break it down per line (e.g.
    # Fozzy's online orders only expose sumActualDiscount at the order level).
    total_discount: float | None = None
    # Loyalty points/cashback the store's own API says this purchase earned — only
    # set when the store actually reports it (ATB/Fozzy don't expose this anywhere
    # we've found; see RESEARCH.md).
    bonuses: float | None = None
    # Loyalty points/cashback *spent* as payment on this purchase — separate from
    # `bonuses` (earned). Same availability caveat.
    bonuses_used: float | None = None


@dataclasses.dataclass
class LoyaltyCode:
    """The store's own customer/loyalty-card code, shown at checkout instead of a
    physical card. `display` says how the store's real app renders it — "qr" or
    "barcode" — not a suggestion, every store we've checked is consistent about it."""

    value: str
    display: str  # "qr" | "barcode"
    expires_at: dt.datetime | None = None  # set when the store issues a rotating code


@dataclasses.dataclass
class LoyaltyBalance:
    """Current bonus/cashback wallet balance, as the store's own app shows it."""

    total: float
    currency: str = "UAH"
    # Bonuses the store has earmarked but not yet released for spending (e.g.
    # Epicentr's separate "notActiveBonuses" bucket) — None when the store
    # doesn't distinguish this.
    pending: float | None = None


@dataclasses.dataclass
class AuthResult:
    """What an adapter hands back after a successful login/refresh."""

    access_token: str | None = None
    refresh_token: str | None = None
    expires_at: dt.datetime | None = None
    extra: dict = dataclasses.field(default_factory=dict)
    # True if the flow needs another step (e.g. waiting for the SMS code) before
    # access_token is usable.
    pending: bool = False


class AdapterError(RuntimeError):
    """Raised by adapters for any request/auth failure; message is shown to the user."""


class NotImplementedYet(AdapterError):
    """Raised by stub adapters (METRO, scanner) that are documented but not wired up."""


class BaseAdapter(abc.ABC):
    store_code: str

    async def start_login(self, phone_number: str) -> AuthResult:
        """Kick off phone+SMS login: send the OTP. Returns pending=True with any
        challenge id the adapter needs to remember (in AuthResult.extra)."""
        raise NotImplementedYet(f"{self.store_code}: OTP login not implemented yet")

    async def confirm_login(self, extra: dict, code: str) -> AuthResult:
        """Confirm the SMS code and exchange it for real tokens."""
        raise NotImplementedYet(f"{self.store_code}: OTP confirmation not implemented yet")

    async def refresh(self, credential_extra: dict, refresh_token: str | None) -> AuthResult:
        """Refresh an expired access token. Default: not supported, caller must re-login."""
        raise AdapterError(f"{self.store_code}: token refresh not supported, please re-authenticate")

    def oauth_authorize_url(self, state: str, redirect_uri: str, code_challenge: str) -> str:
        """For AuthType.oauth_browser stores (e.g. silpo): build the URL the user's
        browser is sent to for an OAuth 2.1 + PKCE authorization-code login. Default:
        not supported."""
        raise NotImplementedYet(f"{self.store_code}: OAuth browser login not implemented")

    async def oauth_exchange(self, code: str, code_verifier: str, redirect_uri: str) -> AuthResult:
        """Exchange the authorization code (from the oauth_authorize_url redirect)
        for tokens. Default: not supported."""
        raise NotImplementedYet(f"{self.store_code}: OAuth browser login not implemented")

    @abc.abstractmethod
    async def fetch_receipts(
        self, access_token: str, extra: dict, since: dt.datetime | None = None
    ) -> list[NormalizedReceipt]:
        """Return receipts (with line items already filled in where the store's API
        allows it in one call; otherwise items may be empty and filled in lazily)."""
        raise NotImplementedError

    def parse_import(self, payload: dict) -> list[NormalizedReceipt]:
        """Parse a manually-captured raw API response (pasted from mitmproxy, when
        this store blocks server-side automation — see atb.py) into normalized
        receipts, without making any network call. Optional; default: unsupported."""
        raise NotImplementedYet(f"{self.store_code}: manual import not supported")

    async def get_loyalty_code(self, access_token: str, extra: dict) -> LoyaltyCode:
        """Fetch the account's loyalty-card code for on-screen display (see
        LoyaltyCode). Optional; default: unsupported. Called live on every UI
        request rather than cached — some stores issue a short-lived rotating
        code (see atb.py)."""
        raise NotImplementedYet(f"{self.store_code}: код картки для цього магазину поки не підтримується")

    async def get_balance(self, access_token: str, extra: dict) -> LoyaltyBalance:
        """Current bonus/cashback balance (see LoyaltyBalance). Optional; default:
        unsupported. Unlike get_loyalty_code this IS cached — collector.py calls it
        once per collection run and stores the result on Account, since it changes
        slowly and accounts.py's list endpoint needs to return it instantly."""
        raise NotImplementedYet(f"{self.store_code}: баланс бонусів для цього магазину поки не підтримується")
