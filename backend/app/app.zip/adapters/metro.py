"""METRO UA (com.supersmart.android.metro.ua) — documented, not wired up yet.

Endpoint is known and was confirmed live (server error proved the shape is right):
    POST https://metroua.supersmart.me/services/v4/order/historical/paid
    Body: {"id": 0, "customerId": "<device-uuid>"}

Blocked on: customerId must be registered as a "Shopper", which happens by scanning
a real in-store cart on first login. See RESEARCH.md. Once that's done this adapter
can be filled in the same shape as atb.py.
"""
from __future__ import annotations

import datetime as dt

from app.adapters.base import BaseAdapter, NormalizedReceipt, NotImplementedYet


class MetroAdapter(BaseAdapter):
    store_code = "metro"

    async def fetch_receipts(
        self, access_token: str, extra: dict, since: dt.datetime | None = None
    ) -> list[NormalizedReceipt]:
        raise NotImplementedYet(
            "METRO: customerId ще не зареєстрований як Shopper (потрібен скан візка в магазині)"
        )
