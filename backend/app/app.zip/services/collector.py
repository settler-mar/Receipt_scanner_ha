"""Runs one collection pass for an Account: call its adapter, upsert receipts,
record a CollectionRun. Used by both the manual "collect now" API and the scheduler.
"""
from __future__ import annotations

import datetime as dt
import logging

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.adapters.base import AdapterError, NormalizedReceipt, NotImplementedYet
from app.adapters.registry import get_adapter
from app.core.security import decrypt, encrypt
from app.core.time import as_utc
from app.models.models import (
    Account,
    AccountStatus,
    CollectionRun,
    Receipt,
    ReceiptItem,
    RunStatus,
)

logger = logging.getLogger(__name__)


async def collect_for_account(db: Session, account: Account, trigger: str = "manual") -> CollectionRun:
    run = CollectionRun(account_id=account.id, trigger=trigger, status=RunStatus.running)
    db.add(run)
    db.commit()
    db.refresh(run)

    try:
        if account.credential is None or not account.credential.access_token_enc:
            raise AdapterError("Немає токена — спершу пройдіть авторизацію для цього акаунта")

        adapter = get_adapter(account.store.code)
        access_token = await ensure_fresh_token(db, account, adapter)
        extra = dict(account.credential.extra or {})
        extra.setdefault("phone_number", account.phone_number)

        # Best-effort and independent of receipt collection below — do this first
        # so a store whose receipts endpoint is broken/blocked (e.g. АТБ's
        # Cloudflare block) still gets its balance refreshed.
        await _refresh_balance(account, adapter, access_token, extra)

        # Collect everything newer than the most recent receipt we already have,
        # with a bit of overlap in case of clock skew / same-day multiple purchases.
        latest = db.execute(
            select(Receipt.purchased_at)
            .where(Receipt.account_id == account.id)
            .order_by(Receipt.purchased_at.desc())
            .limit(1)
        ).scalar_one_or_none()
        latest = as_utc(latest)
        since = (latest - dt.timedelta(days=1)) if latest else None

        normalized_receipts = await adapter.fetch_receipts(access_token, extra, since=since)
        new_count = _persist_receipts(db, account, normalized_receipts)

        run.status = RunStatus.success
        run.receipts_found = len(normalized_receipts)
        run.receipts_new = new_count
        account.status = AccountStatus.active
        account.last_error = None

    except Exception as exc:  # noqa: BLE001 — surfaced to the UI via CollectionRun.error_message
        logger.exception("Collection failed for account %s", account.id)
        run.status = RunStatus.error
        run.error_message = str(exc)
        account.last_error = str(exc)
        if isinstance(exc, AdapterError):
            account.status = AccountStatus.needs_reauth

    finally:
        run.finished_at = dt.datetime.now(dt.timezone.utc)
        db.commit()
        db.refresh(run)

    return run


def import_for_account(db: Session, account: Account, payload: dict) -> CollectionRun:
    """Same persistence path as collect_for_account, but from a manually-pasted
    raw API response instead of a live network call — for stores where automated
    collection is blocked (see AtbAdapter.parse_import)."""
    run = CollectionRun(account_id=account.id, trigger="import", status=RunStatus.running)
    db.add(run)
    db.commit()
    db.refresh(run)

    try:
        adapter = get_adapter(account.store.code)
        normalized_receipts = adapter.parse_import(payload)
        new_count = _persist_receipts(db, account, normalized_receipts)

        run.status = RunStatus.success
        run.receipts_found = len(normalized_receipts)
        run.receipts_new = new_count
        account.last_error = None

    except Exception as exc:  # noqa: BLE001
        logger.exception("Import failed for account %s", account.id)
        run.status = RunStatus.error
        run.error_message = str(exc)
        account.last_error = str(exc)

    finally:
        run.finished_at = dt.datetime.now(dt.timezone.utc)
        db.commit()
        db.refresh(run)

    return run


async def _refresh_balance(account: Account, adapter, access_token: str, extra: dict) -> None:
    """Best-effort: cache the loyalty balance on Account so accounts.py's list
    endpoint can return it instantly instead of live-fetching per row. Silently
    skipped for stores that don't support it (see BaseAdapter.get_balance);
    any other failure is logged but must not fail the collection run itself."""
    try:
        balance = await adapter.get_balance(access_token, extra)
    except NotImplementedYet:
        return
    except AdapterError:
        logger.warning("Could not refresh balance for account %s", account.label, exc_info=True)
        return
    account.bonus_balance = balance.total
    account.bonus_balance_updated_at = dt.datetime.now(dt.timezone.utc)


def _persist_receipts(db: Session, account: Account, normalized_receipts: list[NormalizedReceipt]) -> int:
    """Upserts normalized receipts (skipping ones already stored by external_id),
    returns how many were newly inserted."""
    new_count = 0
    for nr in normalized_receipts:
        existing = db.execute(
            select(Receipt).where(
                Receipt.account_id == account.id, Receipt.external_id == nr.external_id
            )
        ).scalar_one_or_none()
        if existing:
            continue

        receipt = Receipt(
            account_id=account.id,
            store_code=account.store.code,
            external_id=nr.external_id,
            purchased_at=nr.purchased_at,
            total_amount=nr.total_amount,
            currency=nr.currency,
            shop_name=nr.shop_name,
            shop_address=nr.shop_address,
            payment_type=nr.payment_type,
            channel=nr.channel,
            total_discount=(
                nr.total_discount if nr.total_discount is not None
                else sum(it.discount for it in nr.items)
            ),
            bonuses=nr.bonuses,
            raw=nr.raw,
        )
        db.add(receipt)
        for it in nr.items:
            db.add(
                ReceiptItem(
                    receipt=receipt,
                    name=it.name,
                    barcode=it.barcode,
                    category=it.category,
                    quantity=it.quantity,
                    unit=it.unit,
                    unit_price=it.unit_price,
                    total_price=it.total_price,
                    discount=it.discount,
                )
            )
        new_count += 1
    return new_count


async def ensure_fresh_token(db: Session, account: Account, adapter) -> str:
    """Returns a usable access_token, transparently refreshing it first if it's
    expired (or about to expire) and the adapter supports it. Persists any new
    tokens so the next run doesn't have to refresh again."""
    cred = account.credential
    expires_at = as_utc(cred.expires_at)
    expiring_soon = expires_at is not None and expires_at <= dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=2)

    if not expiring_soon:
        return decrypt(cred.access_token_enc)

    logger.info("Refreshing expired token for account %s", account.label)
    refresh_token = decrypt(cred.refresh_token_enc)
    result = await adapter.refresh(dict(cred.extra or {}), refresh_token)

    if result.access_token:
        cred.access_token_enc = encrypt(result.access_token)
    if result.refresh_token:
        cred.refresh_token_enc = encrypt(result.refresh_token)
    if result.expires_at:
        cred.expires_at = result.expires_at
    if result.extra:
        cred.extra = {**(cred.extra or {}), **result.extra}
    db.commit()

    return decrypt(cred.access_token_enc)
