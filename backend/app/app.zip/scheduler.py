"""A single periodic tick (every minute) checks which enabled Schedules are due
and runs a collection for their Account. Simpler and more robust than dynamically
adding/removing APScheduler jobs whenever accounts/schedules change through the API.
"""
from __future__ import annotations

import datetime as dt
import logging

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from croniter import croniter
from sqlalchemy import select

from app.core.time import as_utc
from app.db import SessionLocal
from app.models.models import Account, Schedule
from app.services.collector import collect_for_account

logger = logging.getLogger(__name__)
scheduler = AsyncIOScheduler()


async def _tick() -> None:
    now = dt.datetime.now(dt.timezone.utc)
    db = SessionLocal()
    try:
        due = db.execute(
            select(Schedule).where(Schedule.enabled.is_(True))
        ).scalars().all()

        for schedule in due:
            if schedule.next_run_at is None:
                schedule.next_run_at = croniter(schedule.cron_expression, now).get_next(dt.datetime)
                schedule.next_run_at = schedule.next_run_at.replace(tzinfo=dt.timezone.utc)
                # Bug fixed 26.08.2026: this branch never committed, so next_run_at
                # never actually persisted — every tick saw None again and
                # recomputed it forever, so schedules never became "due". Every
                # account's next_run_at was still None after >24h of the scheduler
                # supposedly running (confirmed live) until this commit was added.
                db.commit()
                continue
            if as_utc(schedule.next_run_at) > now:
                continue

            account = db.get(Account, schedule.account_id)
            if account is None:
                continue

            logger.info("Scheduled collection for account %s", account.label)
            await collect_for_account(db, account, trigger="schedule")

            schedule.last_run_at = now
            schedule.next_run_at = croniter(schedule.cron_expression, now).get_next(dt.datetime)
            schedule.next_run_at = schedule.next_run_at.replace(tzinfo=dt.timezone.utc)
            db.commit()
    finally:
        db.close()


def start_scheduler() -> None:
    scheduler.add_job(_tick, "interval", minutes=1, id="schedule_tick", replace_existing=True)
    scheduler.start()
