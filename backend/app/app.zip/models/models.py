"""Core ORM models.

Domain summary:
  Store       — a receipt source we know how to talk to (atb, fozzy, fora, metro, scanner...).
                Static/seeded reference data, one row per adapter.
  Account     — one "installation" of a store for one person, e.g. "АТБ Максим" vs "АТБ Насті".
                Multiple accounts can point at the same Store.
  Credential  — auth material for an Account (tokens etc.), encrypted at rest, 1:1 with Account.
  Schedule    — how often we auto-collect for an Account.
  CollectionRun — one execution log (manual or scheduled) of pulling receipts for an Account.
  Receipt / ReceiptItem — normalized data, regardless of source store.
"""
from __future__ import annotations

import datetime as dt
import enum
import uuid

from sqlalchemy import (
    JSON,
    DateTime,
    Enum,
    ForeignKey,
    Numeric,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


def _uuid() -> str:
    return str(uuid.uuid4())


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


class AuthType(str, enum.Enum):
    phone_otp = "phone_otp"          # phone + SMS code (ATB, Fozzy, Fora)
    device_uuid = "device_uuid"      # anonymous device id (METRO)
    manual = "manual"                # no automated login (e.g. scanner/OCR)
    oauth_browser = "oauth_browser"  # OAuth 2.1 + PKCE via a real browser login (Silpo MCP)


class AccountStatus(str, enum.Enum):
    pending_otp = "pending_otp"   # OTP sent, awaiting code confirmation
    active = "active"             # has a usable token
    needs_reauth = "needs_reauth" # token expired/invalid, needs a fresh login
    error = "error"


class RunStatus(str, enum.Enum):
    running = "running"
    success = "success"
    partial = "partial"
    error = "error"


class Store(Base):
    __tablename__ = "stores"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    code: Mapped[str] = mapped_column(String, unique=True, index=True)  # atb / fozzy / fora / metro / scanner
    name: Mapped[str] = mapped_column(String)
    auth_type: Mapped[AuthType] = mapped_column(Enum(AuthType))
    enabled: Mapped[bool] = mapped_column(default=True)

    accounts: Mapped[list["Account"]] = relationship(back_populates="store")


class Account(Base):
    __tablename__ = "accounts"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    store_id: Mapped[str] = mapped_column(ForeignKey("stores.id"))
    label: Mapped[str] = mapped_column(String)  # e.g. "АТБ Максим"
    phone_number: Mapped[str | None] = mapped_column(String, nullable=True)
    status: Mapped[AccountStatus] = mapped_column(Enum(AccountStatus), default=AccountStatus.pending_otp)
    last_error: Mapped[str | None] = mapped_column(String, nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)

    # Cached loyalty balance — refreshed by collector.py on each collection run
    # (best-effort, see BaseAdapter.get_balance), not fetched live on page load.
    bonus_balance: Mapped[float | None] = mapped_column(Numeric(12, 2), nullable=True)
    bonus_balance_updated_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    store: Mapped[Store] = relationship(back_populates="accounts")
    credential: Mapped["Credential | None"] = relationship(
        back_populates="account", uselist=False, cascade="all, delete-orphan"
    )
    schedule: Mapped["Schedule | None"] = relationship(
        back_populates="account", uselist=False, cascade="all, delete-orphan"
    )
    runs: Mapped[list["CollectionRun"]] = relationship(back_populates="account", cascade="all, delete-orphan")
    receipts: Mapped[list["Receipt"]] = relationship(back_populates="account", cascade="all, delete-orphan")


class Credential(Base):
    """Auth material for one Account. Sensitive fields are stored encrypted (see core.security)."""

    __tablename__ = "credentials"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    account_id: Mapped[str] = mapped_column(ForeignKey("accounts.id"), unique=True)

    access_token_enc: Mapped[str | None] = mapped_column(String, nullable=True)
    refresh_token_enc: Mapped[str | None] = mapped_column(String, nullable=True)
    expires_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Store-specific extra bits an adapter needs (customerId/deviceId/otp challenge id, etc).
    # Not encrypted — must not contain secrets, only identifiers.
    extra: Mapped[dict] = mapped_column(JSON, default=dict)

    account: Mapped[Account] = relationship(back_populates="credential")


class Schedule(Base):
    __tablename__ = "schedules"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    account_id: Mapped[str] = mapped_column(ForeignKey("accounts.id"), unique=True)
    enabled: Mapped[bool] = mapped_column(default=True)
    # Standard 5-field cron expression, e.g. "0 */6 * * *" = every 6 hours.
    cron_expression: Mapped[str] = mapped_column(String, default="0 12,19 * * *")
    last_run_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    next_run_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    account: Mapped[Account] = relationship(back_populates="schedule")


class CollectionRun(Base):
    __tablename__ = "collection_runs"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    account_id: Mapped[str] = mapped_column(ForeignKey("accounts.id"))
    trigger: Mapped[str] = mapped_column(String, default="manual")  # manual | schedule
    status: Mapped[RunStatus] = mapped_column(Enum(RunStatus), default=RunStatus.running)
    started_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)
    finished_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    receipts_found: Mapped[int] = mapped_column(default=0)
    receipts_new: Mapped[int] = mapped_column(default=0)
    error_message: Mapped[str | None] = mapped_column(String, nullable=True)

    account: Mapped[Account] = relationship(back_populates="runs")


class Receipt(Base):
    __tablename__ = "receipts"
    __table_args__ = (UniqueConstraint("account_id", "external_id", name="uq_receipt_account_external"),)

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    account_id: Mapped[str] = mapped_column(ForeignKey("accounts.id"))
    store_code: Mapped[str] = mapped_column(String, index=True)
    external_id: Mapped[str] = mapped_column(String, index=True)  # store's own receipt/order id

    purchased_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), index=True)
    total_amount: Mapped[float] = mapped_column(Numeric(12, 2))
    currency: Mapped[str] = mapped_column(String, default="UAH")
    shop_name: Mapped[str | None] = mapped_column(String, nullable=True)
    shop_address: Mapped[str | None] = mapped_column(String, nullable=True)
    payment_type: Mapped[str | None] = mapped_column(String, nullable=True)
    channel: Mapped[str] = mapped_column(String, default="offline")  # "offline" | "online"
    total_discount: Mapped[float] = mapped_column(Numeric(12, 2), default=0)  # sum of item discounts
    bonuses: Mapped[float | None] = mapped_column(Numeric(12, 2), nullable=True)  # loyalty points/cashback earned, when the store's API reports it
    bonuses_used: Mapped[float | None] = mapped_column(Numeric(12, 2), nullable=True)  # loyalty points/cashback spent as payment, when reported

    raw: Mapped[dict] = mapped_column(JSON, default=dict)  # original payload, for future re-parsing
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)

    account: Mapped[Account] = relationship(back_populates="receipts")
    items: Mapped[list["ReceiptItem"]] = relationship(back_populates="receipt", cascade="all, delete-orphan")


class ReceiptItem(Base):
    __tablename__ = "receipt_items"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    receipt_id: Mapped[str] = mapped_column(ForeignKey("receipts.id"))

    name: Mapped[str] = mapped_column(String)
    barcode: Mapped[str | None] = mapped_column(String, nullable=True)
    category: Mapped[str | None] = mapped_column(String, nullable=True)
    quantity: Mapped[float] = mapped_column(Numeric(12, 3), default=1)
    unit: Mapped[str | None] = mapped_column(String, nullable=True)
    unit_price: Mapped[float | None] = mapped_column(Numeric(12, 2), nullable=True)
    total_price: Mapped[float] = mapped_column(Numeric(12, 2))
    discount: Mapped[float] = mapped_column(Numeric(12, 2), default=0)

    receipt: Mapped[Receipt] = relationship(back_populates="items")
