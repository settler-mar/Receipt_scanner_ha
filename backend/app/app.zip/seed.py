from sqlalchemy import select

from app.db import SessionLocal
from app.models.models import AuthType, Store

STORES = [
    ("atb", "АТБ-Маркет", AuthType.phone_otp),
    ("fozzy", "Fozzy", AuthType.phone_otp),
    ("fora", "Фора", AuthType.phone_otp),
    ("metro", "METRO", AuthType.device_uuid),
    ("silpo", "Сільпо", AuthType.oauth_browser),
    ("epicentrk", "Епіцентр К", AuthType.phone_otp),
    ("scanner", "Сканер (OCR)", AuthType.manual),
]


def seed_stores() -> None:
    db = SessionLocal()
    try:
        existing = {s.code for s in db.execute(select(Store)).scalars().all()}
        for code, name, auth_type in STORES:
            if code in existing:
                continue
            db.add(Store(code=code, name=name, auth_type=auth_type))
        db.commit()
    finally:
        db.close()
