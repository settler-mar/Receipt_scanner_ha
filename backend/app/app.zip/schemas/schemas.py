from __future__ import annotations

import datetime as dt

from pydantic import BaseModel, ConfigDict


class StoreOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    code: str
    name: str
    auth_type: str
    enabled: bool


class ScheduleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    enabled: bool
    cron_expression: str
    last_run_at: dt.datetime | None
    next_run_at: dt.datetime | None


class ScheduleUpdate(BaseModel):
    enabled: bool | None = None
    cron_expression: str | None = None


class AccountCreate(BaseModel):
    store_code: str
    label: str
    phone_number: str | None = None


class AccountOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    label: str
    phone_number: str | None
    status: str
    last_error: str | None
    created_at: dt.datetime
    store: StoreOut
    schedule: ScheduleOut | None = None
    receipt_count: int = 0
    last_collected_at: dt.datetime | None = None
    bonus_balance: float | None = None
    bonus_balance_updated_at: dt.datetime | None = None


class ImportPayload(BaseModel):
    """Raw API response body pasted from a mitmproxy capture (e.g. АТБ getReceipts),
    for stores where live automated collection is blocked. See adapters/*.py
    parse_import() for the exact expected shape per store."""

    payload: dict


class TokenBootstrap(BaseModel):
    """Manual token entry — bridges the gap until real OTP flows are automated
    per store (see RESEARCH.md). Paste a token captured via mitmproxy."""

    access_token: str
    refresh_token: str | None = None
    expires_at: dt.datetime | None = None
    extra: dict = {}


class LoginStart(BaseModel):
    phone_number: str


class LoginConfirm(BaseModel):
    code: str


class LoyaltyCodeOut(BaseModel):
    value: str
    display: str  # "qr" | "barcode"
    expires_at: dt.datetime | None = None


class RunOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    trigger: str
    status: str
    started_at: dt.datetime
    finished_at: dt.datetime | None
    receipts_found: int
    receipts_new: int
    error_message: str | None


class ReceiptItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    barcode: str | None
    category: str | None
    quantity: float
    unit: str | None
    unit_price: float | None
    total_price: float
    discount: float


class ReceiptOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    account_id: str
    store_code: str
    external_id: str
    purchased_at: dt.datetime
    total_amount: float
    currency: str
    shop_name: str | None
    shop_address: str | None
    payment_type: str | None
    channel: str
    total_discount: float
    bonuses: float | None = None
    bonuses_used: float | None = None
    account_label: str = ""
    items: list[ReceiptItemOut] = []


class ReceiptListOut(BaseModel):
    total: int
    items: list[ReceiptOut]


class DashboardStats(BaseModel):
    total_receipts: int
    total_spent: float
    total_discount: float
    total_bonuses: float
    total_bonuses_used: float
    accounts_active: int
    accounts_needs_attention: int
    last_run_at: dt.datetime | None
