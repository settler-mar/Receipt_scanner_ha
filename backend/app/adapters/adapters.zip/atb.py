"""АТБ-Маркет (com.atb.atbmarket).

Реализация авторизации standard OIDC authorization_code + PKCE flow против ://atbmarket.com
с прохождением SMS OTP шага.

Порядок запросов:
  1. POST /register/login              {"phoneNumber": "+380..."}   -> {"token": <otp_token>}
  2. GET  /auth/auth?client_id=third_mobile... -> 303 на /auth/third_mobile/interaction/<interaction_id>
  3. POST /auth/third_mobile/interaction/<interaction_id>/login (передача otp) -> {"returnTo": "<url>"}
  4. GET  <returnTo>                    -> 303, получение ?code=<auth_code>
  5. POST /auth/token                   -> {"access_token", "id_token", ...}
"""

from __future__ import annotations

import base64
import datetime as dt
import hashlib
import re
import secrets
import urllib.parse

from app.adapters.base import (
    AdapterError,
    AuthResult,
    BaseAdapter,
    LoyaltyBalance,
    LoyaltyCode,
    NormalizedItem,
    NormalizedReceipt,
)
from app.core.http import AsyncClient

BASE_URL = "https://ereceipt.atbmarket.com/EReceipt_MP/eReceipts/1.0"
AUTH_BASE = "https://mobapp.atbmarket.com"
# Separate white-label loyalty backend (shared across several UA retail chains,
# going by the domain) — not behind the same Cloudflare bot-management as
# mobapp/ereceipt, so unlike getReceipts this one isn't blocked from the server.
WALLET_URL = "https://wallet-prod.pc-service.ua"
# Static per-app Basic auth credential the mobile client uses to call /register/login.
REGISTER_BASIC_AUTH = "Basic cmVnX3VzZXI6YmFzaWMqODhwYXNzd29yZCFwcm9kOTk="

# Базовые заголовки мобильного клиента для интеграции с API.
_AUTH_HEADERS = {
    "Accept": "application/json, text/plain, */*",
    "Accept-Encoding": "gzip",
    "User-Agent": "okhttp/4.9.2",
}

def _pkce_pair() -> tuple[str, str]:
    verifier = base64.urlsafe_b64encode(secrets.token_bytes(64)).rstrip(b"=").decode()
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    return verifier, challenge


_FRACTION_RE = re.compile(r"\.(\d+)")


def _parse_dt(value: str) -> dt.datetime:
    """wallet-prod.pc-service.ua's expiredIn carries .NET-style fractional seconds
    with an arbitrary digit count (e.g. ".5944481", 7 digits) — same issue as
    Fozzy's timestamps (see fozzy.py), Python's fromisoformat only accepts 3 or 6."""
    value = _FRACTION_RE.sub(lambda m: "." + m.group(1)[:6].ljust(6, "0"), value, count=1)
    return dt.datetime.fromisoformat(value)


class AtbAdapter(BaseAdapter):
    store_code = "atb"

    async def start_login(self, phone_number: str) -> AuthResult:
        code_verifier, code_challenge = _pkce_pair()

        async with AsyncClient(timeout=20, headers=_AUTH_HEADERS) as client:
            resp = await client.post(
                f"{AUTH_BASE}/register/login",
                headers={"Authorization": REGISTER_BASIC_AUTH, "Content-Type": "application/json"},
                json={"phoneNumber": phone_number},
            )
            if resp.status_code != 201:
                raise AdapterError(f"АТБ: не вдалось надіслати SMS ({resp.status_code}): {resp.text[:200]}")
            otp_token = resp.json()["token"]

            auth_resp = await client.get(
                f"{AUTH_BASE}/auth/auth",
                params={
                    "client_id": "third_mobile",
                    "scope": "openid phone",
                    "prompt": "login",
                    "response_type": "code",
                    "code_challenge_method": "S256",
                    "code_challenge": code_challenge,
                },
                follow_redirects=False,
            )
            if auth_resp.status_code != 303 or "location" not in auth_resp.headers:
                raise AdapterError(f"АТБ: неочікувана відповідь /auth/auth ({auth_resp.status_code})")
            interaction_id = auth_resp.headers["location"].rsplit("/", 1)[-1]
            cookies = dict(client.cookies)

        return AuthResult(
            pending=True,
            extra={
                "otp_confirm_token": otp_token,
                "interaction_id": interaction_id,
                "code_verifier": code_verifier,
                "auth_cookies": cookies,
            },
        )

    async def confirm_login(self, extra: dict, code: str) -> AuthResult:
        interaction_id = extra.get("interaction_id")
        otp_token = extra.get("otp_confirm_token")
        code_verifier = extra.get("code_verifier")
        cookies = extra.get("auth_cookies") or {}
        if not (interaction_id and otp_token and code_verifier):
            raise AdapterError("АТБ: сесія логіну застаріла — почніть спочатку")

        async with AsyncClient(timeout=20, cookies=cookies, headers=_AUTH_HEADERS) as client:
            login_resp = await client.post(
                f"{AUTH_BASE}/auth/third_mobile/interaction/{interaction_id}/login",
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                data={"token": otp_token, "otp": code},
            )
            if login_resp.status_code != 200:
                raise AdapterError("АТБ: невірний код підтвердження")
            return_to = login_resp.json()["returnTo"]

            resume_resp = await client.get(return_to, follow_redirects=False)
            if resume_resp.status_code != 303 or "location" not in resume_resp.headers:
                raise AdapterError(f"АТБ: неочікувана відповідь при резюмуванні ({resume_resp.status_code})")
            query = urllib.parse.urlparse(resume_resp.headers["location"]).query
            auth_code = urllib.parse.parse_qs(query).get("code", [None])[0]
            if not auth_code:
                raise AdapterError("АТБ: не отримано код авторизації")

            token_resp = await client.post(
                f"{AUTH_BASE}/auth/token",
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                data={
                    "code": auth_code,
                    "code_verifier": code_verifier,
                    "grant_type": "authorization_code",
                    "client_id": "third_mobile",
                },
            )
            if token_resp.status_code != 200:
                raise AdapterError(f"АТБ: не вдалось обміняти код на токен ({token_resp.status_code})")
            payload = token_resp.json()

        expires_at = dt.datetime.now(dt.timezone.utc) + dt.timedelta(seconds=payload.get("expires_in", 3600))
        return AuthResult(access_token=payload["id_token"], expires_at=expires_at)

    async def fetch_receipts(
        self, access_token: str, extra: dict, since: dt.datetime | None = None
    ) -> list[NormalizedReceipt]:
        phone = extra.get("phone_number")
        if not phone:
            raise ValueError("АТБ: в extra отсутствует phone_number (clientId)")

        headers = {**_AUTH_HEADERS, "Authorization": f"Bearer {access_token}"}
        receipts: list[NormalizedReceipt] = []
        offset = 1
        page_size = 20

        async with AsyncClient(timeout=20) as client:
            while True:
                resp = await client.post(
                    f"{BASE_URL}/getReceipts",
                    headers=headers,
                    json={
                        "clientId": phone,
                        "checkSortBy": "date",
                        "checkOffset": offset,
                        "checkLimit": page_size,
                    },
                )
                resp.raise_for_status()
                payload = resp.json()
                batch = payload.get("Data") or []
                if not batch:
                    break

                stop = False
                for entry in batch:
                    normalized = _normalize(entry)
                    if since and normalized.purchased_at < since:
                        stop = True
                        break
                    receipts.append(normalized)

                if stop or len(batch) < page_size:
                    break
                offset += 1

        return receipts

    def parse_import(self, payload: dict) -> list[NormalizedReceipt]:
        """Парсинг структуры JSON данных, полученных из API getReceipts,
        и запуск стандартного процесса нормализации чеков."""
        entries = payload.get("Data") or []
        return [_normalize(e) for e in entries]

    async def get_loyalty_code(self, access_token: str, extra: dict) -> LoyaltyCode:
        """GET /api/v1/Client/pin on the separate wallet-prod.pc-service.ua host —
        confirmed live, not Cloudflare-gated like eReceipts. Returns a rotating
        code (~3h window observed) plus a short human-readable `pin` fallback; we
        only surface the code (as a QR, matching what the real app shows)."""
        async with AsyncClient(timeout=20) as client:
            resp = await client.get(
                f"{WALLET_URL}/api/v1/Client/pin",
                headers={**_AUTH_HEADERS, "Authorization": f"Bearer {access_token}"},
            )
        if resp.status_code != 200:
            raise AdapterError(f"АТБ: не вдалось отримати код картки ({resp.status_code})")
        result = resp.json().get("result") or {}
        barcode = result.get("barcode")
        if not barcode:
            raise AdapterError("АТБ: код картки відсутній у відповіді")
        expires_at = None
        if result.get("expiredIn"):
            expires_at = _parse_dt(result["expiredIn"])
        return LoyaltyCode(value=barcode, display="qr", expires_at=expires_at)

    async def get_balance(self, access_token: str, extra: dict) -> LoyaltyBalance:
        """Same wallet-prod.pc-service.ua host — this is a "round up the change"
        program (remainderParams describes the rounding rules), `balance` is what's
        accumulated so far."""
        async with AsyncClient(timeout=20) as client:
            resp = await client.get(
                f"{WALLET_URL}/api/v1/Client/balanceByClientId",
                headers={**_AUTH_HEADERS, "Authorization": f"Bearer {access_token}"},
            )
        if resp.status_code != 200:
            raise AdapterError(f"АТБ: не вдалось отримати баланс ({resp.status_code})")
        result = resp.json().get("result") or {}
        if "balance" not in result:
            raise AdapterError("АТБ: баланс відсутній у відповіді")
        return LoyaltyBalance(total=float(result["balance"]))


def _normalize(entry: dict) -> NormalizedReceipt:
    shop = entry.get("shop") or {}
    rcpt = entry.get("rcpt") or {}
    details = entry.get("details") or []

    purchased_at = dt.datetime.strptime(rcpt["dt"], "%d.%m.%Y %H:%M:%S").replace(
        tzinfo=dt.timezone.utc
    )
    external_id = f"{rcpt.get('rroFiscal', shop.get('id'))}:{rcpt.get('rNum')}:{rcpt.get('zNum')}"

    items = [
        NormalizedItem(
            name=d.get("name", "").strip(),
            quantity=float(d.get("qty") or 1),
            unit_price=_to_float(d.get("price")),
            total_price=_to_float(d.get("sum")) or 0,
            discount=_to_float(d.get("discount")) or 0,
            barcode=d.get("bar") or None,
        )
        for d in details
    ]

    return NormalizedReceipt(
        external_id=external_id,
        purchased_at=purchased_at,
        total_amount=_to_float(rcpt.get("total")) or 0,
        shop_name=shop.get("name"),
        shop_address=shop.get("addr"),
        payment_type=None,
        items=items,
        raw=entry,
    )


def _to_float(value) -> float | None:
    if value in (None, ""):
        return None
    return float(str(value).replace(",", "."))
