"""Дніпро-М (dnipro-m.ua) — інструменти/будматеріали. Не мобільний застосунок,
особистий кабінет на сайті (Yii2, PHP-сесія + cookie), на відміну від решти
мереж у цьому проєкті.

Auth: телефон + SMS-код — АЛЕ на відміну від усіх інших мереж тут навіть
одноразовий bootstrap сесії не працює з бекенда. Два незалежних живих тести:
  1. Реплей повного набору cookie, щойно скопійованих із активної сесії
     реального браузера (тим самим GET-запитом, 18 секунд по тому) — сервер
     відповідає 403 "Необхідно увійти" і видає СВІЖИЙ PHPSESSID замість мого,
     ніби cookie не було взагалі.
  2. Сам крок обміну SMS-коду на сесію (`POST /check-code/`), виконаний з
     бекенда (а не з телефона/браузера) одразу після того, як
     `/phone-verification/` в реальному браузері відправив SMS — теж провал,
     400 "Не вдалося перевірити передані дані" (стандартна Yii2-помилка
     CSRF-валідації), знову зі свіжим PHPSESSID у відповіді.
Обидва рази бекенд і телефон були в одній локальній мережі (той самий
зовнішній IP) — це не банальний IP-бан. Найімовірніше — TLS/JA3-відбиток
або інша прив'язка на рівні з'єднання, той самий клас захисту, що й
Cloudflare в АТБ (RESEARCH.md). Далі підбирати заголовки/відбитки НЕ
пробуємо — це вже обхід, а не reverse engineering.

Тому: `start_login`/`confirm_login` кидають пояснювальну помилку (як Fozzy),
А `fetch_receipts`/`get_balance`/`get_warranty_document` нижче лишаються
повністю реалізованими (як `AtbAdapter.fetch_receipts`) — код правильний,
просто зараз не спрацює для жодної сесії, здобутої з цієї машини.

**Робочий шлях — ручний імпорт** (`parse_import`, як і в АТБ): користувач сам
відкриває "Мої замовлення" в кабінеті на сайті (справжня, свого браузера
сесія), у DevTools → Network копіює тіло відповіді `GET
/cabinet/order/history/` і вставляє через "Ручний імпорт" в UI акаунта.

Пошук по каталогу (`search_catalog`) авторизації не потребує взагалі і
працює без жодних застережень — окремий публічний ендпоінт.

Ендпоінти (усі під `/cabinet/`, потребують cookie+csrf з активної сесії):
  GET /cabinet/order/history/                    — історія замовлень, з позиціями
  GET /cabinet/default/bonuses-info/              — баланс бонусів + персональна ставка
  GET /cabinet/order/get-order-warranty-card/     — PDF гарантійного талону по order_id
  GET /search/drop-down/?q=<текст>                — публічний пошук, авторизація НЕ потрібна
"""
from __future__ import annotations

import datetime as dt

import httpx

from app.adapters.base import (
    AdapterError,
    AuthResult,
    BaseAdapter,
    CatalogProduct,
    LoyaltyBalance,
    NormalizedItem,
    NormalizedReceipt,
)

BASE_URL = "https://dnipro-m.ua"


def _to_float(value) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _headers(extra: dict) -> dict:
    cookie = extra.get("cookie")
    if not cookie:
        raise AdapterError("Дніпро-М: немає збереженої сесії — увійдіть повторно (див. docstring адаптера)")
    return {
        "Cookie": cookie,
        "X-CSRF-Token": extra.get("csrf_token") or "",
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json, text/plain, */*",
    }


class DniproMAdapter(BaseAdapter):
    store_code = "dnipro-m"

    async def start_login(self, phone_number: str) -> AuthResult:
        raise AdapterError(
            "Дніпро-М: автоматичний вхід і навіть ручний перенос сесії з браузера не працюють — "
            "сервер не приймає сесію, встановлену не з вашого власного пристрою (перевірено вживу "
            "двома способами, див. docstring модуля). Використовуйте \"Ручний імпорт\": скопіюйте "
            "відповідь /cabinet/order/history/ з DevTools вашого браузера."
        )

    async def confirm_login(self, extra: dict, code: str) -> AuthResult:
        raise AdapterError("Дніпро-М: автоматичний вхід недоступний (див. docstring модуля)")

    def parse_import(self, payload: dict) -> list[NormalizedReceipt]:
        """Очікує тіло відповіді GET /cabinet/order/history/ як є (скопійоване
        з DevTools реального, вже залогіненого браузера) — {"status", "orders": [...]}."""
        entries = payload.get("orders") or []
        return [_normalize(e) for e in entries]

    async def fetch_receipts(
        self, access_token: str, extra: dict, since: dt.datetime | None = None
    ) -> list[NormalizedReceipt]:
        headers = _headers(extra)
        receipts: list[NormalizedReceipt] = []
        offset = 0

        async with httpx.AsyncClient(timeout=20, base_url=BASE_URL) as client:
            while True:
                params = {"offset": offset} if offset else {}
                resp = await client.get("/cabinet/order/history/", headers=headers, params=params)
                if resp.status_code != 200:
                    raise AdapterError(f"Дніпро-М: історія замовлень повернула {resp.status_code}")
                data = resp.json()
                if data.get("status") != "success":
                    raise AdapterError(f"Дніпро-М: {data}")

                orders = data.get("orders") or []
                if not orders:
                    break
                stop = False
                for o in orders:
                    normalized = _normalize(o)
                    if since and normalized.purchased_at < since:
                        stop = True
                        break
                    receipts.append(normalized)
                if stop or not data.get("orders_left"):
                    break
                offset = data.get("offset") or (offset + len(orders))

        return receipts

    async def get_balance(self, access_token: str, extra: dict) -> LoyaltyBalance:
        """`rate` is the account's current personal cashback/discount percent
        (loyalty tier) — surfaced as LoyaltyBalance.discount_percent, distinct
        from the bonus-point wallet total."""
        headers = _headers(extra)
        async with httpx.AsyncClient(timeout=20, base_url=BASE_URL) as client:
            resp = await client.get("/cabinet/default/bonuses-info/", headers=headers)
        if resp.status_code != 200:
            raise AdapterError(f"Дніпро-М: не вдалось отримати баланс ({resp.status_code})")
        data = (resp.json() or {}).get("data") or {}
        if "total_bonuses" not in data:
            raise AdapterError("Дніпро-М: баланс відсутній у відповіді")
        return LoyaltyBalance(
            total=float(data["total_bonuses"]),
            discount_percent=_to_float(data.get("rate")),
        )

    async def search_catalog(self, access_token: str | None, extra: dict, query: str) -> list[CatalogProduct]:
        """Public instant-search endpoint used by the site's own search box —
        confirmed live with no cookie/csrf at all, same as ATB's multisearch.io."""
        headers = {"Accept": "application/json, text/plain, */*", "X-Requested-With": "XMLHttpRequest"}
        async with httpx.AsyncClient(timeout=15, base_url=BASE_URL) as client:
            resp = await client.get("/search/drop-down/", headers=headers, params={"q": query})
        if resp.status_code != 200:
            raise AdapterError(f"Дніпро-М: пошук товарів повернув {resp.status_code}")
        data = resp.json()
        products: list[CatalogProduct] = []
        for item in data.get("products") or []:
            price = _to_float(item.get("price_new"))
            if price is None:
                continue
            name = item.get("name") or {}
            products.append(
                CatalogProduct(
                    name=name.get("uk") or name.get("ru") or "",
                    price=price,
                    image_url=item.get("product_photo"),
                    product_url=item.get("url"),
                    in_stock=item.get("is_available"),
                )
            )
        return products

    async def get_warranty_document(self, access_token: str | None, extra: dict, external_id: str) -> bytes:
        """Returns the raw PDF bytes of the official warranty card for one order
        (`order_id` = Receipt.external_id, i.e. this store's own order_number).
        Only orders with has_warranty_card=true (see _normalize -> has_warranty)
        actually have one — callers should check that first."""
        headers = _headers(extra)
        async with httpx.AsyncClient(timeout=20, base_url=BASE_URL) as client:
            resp = await client.get(
                "/cabinet/order/get-order-warranty-card/", headers=headers, params={"order_id": external_id}
            )
        if resp.status_code != 200 or not resp.content:
            raise AdapterError(f"Дніпро-М: не вдалось отримати гарантійний талон ({resp.status_code})")
        return resp.content


def _normalize(o: dict) -> NormalizedReceipt:
    purchased_at = dt.datetime.fromisoformat(o["created_at"])
    channel = "online" if o.get("creation_provider") == "site" else "offline"

    delivery_data = o.get("delivery_data") or {}
    shop_address = delivery_data.get("address") or o.get("delivery_city_name")

    current_bonus = o.get("current_purchase_bonuses")
    bonuses = _to_float(current_bonus) if current_bonus not in (None, "") else None
    debit = o.get("bonuses_debiting_amount")
    bonuses_used = _to_float(debit) if debit is not None else None

    items = [_item_from(it) for it in (o.get("order_items") or [])]

    return NormalizedReceipt(
        external_id=str(o["order_number"]),
        purchased_at=purchased_at,
        total_amount=_to_float(o.get("total")) or 0.0,
        shop_name=o.get("delivery_name"),
        shop_address=shop_address,
        payment_type=o.get("payment_name"),
        channel=channel,
        items=items,
        bonuses=bonuses,
        bonuses_used=bonuses_used,
        has_warranty=bool(o.get("has_warranty_card")),
        raw=o,
    )


def _item_from(it: dict) -> NormalizedItem:
    # `price` is per-unit before discount; `discount_cost` is per-unit AFTER
    # discount (confirmed live: price=399, discount=81, discount_cost=318 for
    # qty=1 — 399-81=318). `discount` itself is per-unit currency, not a percent.
    price = _to_float(it.get("price")) or 0.0
    qty = _to_float(it.get("itemQuantity")) or 1.0
    discount_cost = _to_float(it.get("discount_cost"))
    unit_after = discount_cost if discount_cost is not None else price
    return NormalizedItem(
        name=(it.get("name") or "").strip(),
        quantity=qty,
        unit_price=price,
        total_price=round(unit_after * qty, 2),
        discount=round((price - unit_after) * qty, 2),
        barcode=it.get("code"),
    )
