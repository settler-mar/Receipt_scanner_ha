"""Fozzy (ua.fozzy.android).

Auth flow is fully reverse-engineered but CANNOT be automated end-to-end: the
first step is gated by a Google reCAPTCHA token generated on-device.

  1. POST https://auth.fozzyshop.ua/SendOtp
     {"captchaInput": "<reCAPTCHA token, ~1500 chars>", "phoneNumber": "+380..."}
     -> {"secondsLeftTilNextTry": 300, "otpLength": 6, "token": "<otp_token JWT>"}
  2. POST https://auth.fozzyshop.ua/ConfirmPhone
     {"otpCode": "123456", "phoneNumber": "+380...", "token": "<otp_token>"}
     -> {"token": "<auth_token JWT with mobilephone/barcode/member claims>"}
  3. POST https://auth.fozzyshop.ua/connect/token
     Authorization: Basic Zm96enlfbW9iaWxlX2FuZHJvaWQ6Zm96enlfbW9iaWxlX2FuZHJvaWRfc2VjcmV0
     form: grant_type=auth_token&auth_token=<auth_token>&client_id=fozzy_mobile_android
     -> {"access_token": "<JWT, used as Bearer everywhere else>", "expires_in", "refresh_token", ...}

Step 1's captchaInput can't be produced by a plain HTTP client — it comes from
Google's reCAPTCHA SDK running inside the real app, tied to device attestation.
Solving/bypassing that is out of scope (would be anti-bot circumvention, not just
reverse engineering), so start_login raises with an explanation instead of trying.
Steps 2-3 are implemented for reference/completeness but are unreachable without a
valid step-1 otp_token.

The practical way in: the captcha only has to be beaten *once*. `connect/token`
also accepts grant_type=refresh_token (confirmed live) and rotates the refresh
token on every use, so after a single manual token bootstrap (paste access_token
*and* refresh_token from mitmproxy in the UI) this adapter keeps itself logged in
indefinitely via `refresh()` — SendOtp/reCAPTCHA never need to run again unless
the stored refresh_token itself gets revoked (e.g. the user logs out elsewhere).

Two receipt sources, each on its own API host but the same Bearer token works for
both:
  - loyaltyexpapi.fozzy.ua  in-store (offline) purchases — chequeheaders + chequeinfo
  - api.tecom.fozzyshop.ua  delivery/Click&Collect orders — a JSON-RPC gateway
    ("TEComGlobal", same {"Method", "data"} shape as Fora's FZGlobal but with the
    Data key lowercased): OrderHeadsList lists orders (and already includes the
    total discount as `sumActualDiscount`, negative), GetOrderDetail({"orderId": id})
    returns line items. Items with lineStateId==1 ("Видалено") were removed from the
    order during picking/substitution and have countActual=0 — skipped entirely.
"""
from __future__ import annotations

import base64
import datetime as dt
import json
import re
import urllib.parse

import httpx

from app.adapters.base import (
    AdapterError,
    AuthResult,
    BaseAdapter,
    CatalogProduct,
    LoyaltyCode,
    NormalizedItem,
    NormalizedReceipt,
)

BASE_URL = "https://loyaltyexpapi.fozzy.ua/api"
TECOM_URL = "https://api.tecom.fozzyshop.ua/api/2.0/exec/TEComGlobal"
AUTH_BASE = "https://auth.fozzyshop.ua"
CONNECT_BASIC_AUTH = "Basic Zm96enlfbW9iaWxlX2FuZHJvaWQ6Zm96enlfbW9iaWxlX2FuZHJvaWRfc2VjcmV0"
# Plain REST search — same host as the TEComGlobal RPC gateway (api.tecom.fozzyshop.ua)
# but a different API version/style, not a "Method" call. MerchantId=4 is a fixed
# "Fozzy" brand id within the shared Fozzy Group backend; FilialId=51 is this
# account's own/nearby store, captured live from a real in-app search (RESEARCH.md)
# — re-capture if search results ever look wrong for a different city.
CATALOG_URL = "https://api.tecom.fozzyshop.ua/api/3.0/Catalog/products"
CATALOG_MERCHANT_ID = "4"
CATALOG_FILIAL_ID = "51"

_FRACTION_RE = re.compile(r"\.(\d+)")


def _decode_jwt_claims(token: str) -> dict:
    """Unverified decode of a JWT's payload segment — fine here since we're only
    reading a claim out of a token we ourselves obtained and already trust as a
    Bearer credential, not authenticating anything with it."""
    try:
        payload_b64 = token.split(".")[1]
        payload_b64 += "=" * (-len(payload_b64) % 4)
        return json.loads(base64.urlsafe_b64decode(payload_b64))
    except (IndexError, ValueError):
        return {}


def _parse_dt(value: str) -> dt.datetime:
    """TEComGlobal timestamps carry .NET-style fractional seconds with an
    arbitrary number of digits (".63", ".2087532", ...) — Python's fromisoformat
    only accepts exactly 3 or 6, so pad/truncate to 6 first."""
    value = _FRACTION_RE.sub(lambda m: "." + m.group(1)[:6].ljust(6, "0"), value, count=1)
    parsed = dt.datetime.fromisoformat(value)
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=dt.timezone.utc)


class FozzyAdapter(BaseAdapter):
    store_code = "fozzy"

    async def start_login(self, phone_number: str) -> AuthResult:
        raise AdapterError(
            "Fozzy: автоматичний вхід недоступний — крок SendOtp вимагає токен reCAPTCHA, "
            "згенерований мобільним застосунком на пристрої; обхід цієї перевірки навмисно "
            "не реалізовано (див. docstring модуля)."
        )

    async def confirm_login(self, extra: dict, code: str) -> AuthResult:
        # Reachable only if start_login is ever updated to produce a real otp_token
        # (see module docstring) — kept implemented so that day only needs step 1 fixed.
        otp_token = extra.get("otp_token")
        phone_number = extra.get("phone_number")
        if not (otp_token and phone_number):
            raise AdapterError("Fozzy: сесія логіну застаріла — почніть спочатку")

        async with httpx.AsyncClient(timeout=20) as client:
            confirm_resp = await client.post(
                f"{AUTH_BASE}/ConfirmPhone",
                json={"otpCode": code, "phoneNumber": phone_number, "token": otp_token},
            )
            if confirm_resp.status_code != 201:
                raise AdapterError("Fozzy: невірний код підтвердження")
            auth_token = confirm_resp.json()["token"]

            return await _exchange(client, {"grant_type": "auth_token", "auth_token": auth_token})

    async def get_loyalty_code(self, access_token: str, extra: dict) -> LoyaltyCode:
        """No separate API call needed — the access_token itself is a JWT with the
        loyalty barcode as a claim (confirmed: same value the real app's card
        screen shows). Static (doesn't rotate), so no expires_at."""
        claims = _decode_jwt_claims(access_token)
        barcode = claims.get("barcode")
        if not barcode:
            raise AdapterError("Fozzy: код картки відсутній у токені")
        return LoyaltyCode(value=barcode, display="qr")

    async def refresh(self, credential_extra: dict, refresh_token: str | None) -> AuthResult:
        if not refresh_token:
            raise AdapterError("Fozzy: немає refresh_token, потрібен повторний вхід")
        async with httpx.AsyncClient(timeout=20) as client:
            return await _exchange(
                client, {"grant_type": "refresh_token", "refresh_token": refresh_token}
            )

    async def search_catalog(self, access_token: str | None, extra: dict, query: str) -> list[CatalogProduct]:
        """GET .../api/3.0/Catalog/products?CustomFilter=<query> — a plain REST
        search on the same host (api.tecom.fozzyshop.ua) fetch_receipts already
        talks to for online orders, just a different API version/style (not the
        TEComGlobal RPC gateway). Same Bearer token + same required headers as
        fetch_receipts."""
        if not access_token:
            raise AdapterError("Fozzy: пошук по каталогу потребує токена")
        headers = {
            "Authorization": f"Bearer {access_token}",
            "appVersionName": "1.108.0GMS",
            "clientSdkVersion": "33",
            "brand": "Xiaomi",
            "x-client-platform": "android",
        }
        params = {
            "MerchantId": CATALOG_MERCHANT_ID,
            "FilialId": CATALOG_FILIAL_ID,
            "DisplayOnSite": "true",
            "DeliveryType": "2",
            "CustomFilter": query,
            "PageSize": "36",
            "PageNum": "1",
        }
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.get(CATALOG_URL, headers=headers, params=params)
        if resp.status_code != 200:
            raise AdapterError(f"Fozzy: пошук товарів повернув {resp.status_code}")
        data = resp.json()
        products: list[CatalogProduct] = []
        for item in data.get("items") or []:
            try:
                price = float(item["price"])
            except (KeyError, TypeError, ValueError):
                continue
            products.append(
                CatalogProduct(
                    name=item.get("name") or "",
                    price=price,
                    unit=item.get("unit"),
                    image_url=item.get("mainImage") or None,
                    in_stock=(item.get("quantity") or 0) > 0,
                )
            )
        return products

    async def fetch_receipts(
        self, access_token: str, extra: dict, since: dt.datetime | None = None
    ) -> list[NormalizedReceipt]:
        headers = {
            "Authorization": f"Bearer {access_token}",
            # loyaltyexpapi.fozzy.ua 401s without these — not otherwise validated,
            # just required to be present.
            "appVersionName": "1.108.0GMS",
            "clientSdkVersion": "33",
            "brand": "Xiaomi",
            "x-client-platform": "android",
        }
        receipts: list[NormalizedReceipt] = []

        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.get(f"{BASE_URL}/1.0/chequeheaders", headers=headers)
            resp.raise_for_status()
            payload = resp.json()

            headers_flat = [
                cheque
                for month in payload.get("chequeMonthList") or []
                for cheque in month.get("chequeList") or []
            ]

            for header in headers_flat:
                purchased_at = dt.datetime.fromisoformat(header["created"].replace("Z", "+00:00"))
                if since and purchased_at < since:
                    continue

                detail = await _fetch_detail(client, headers, header)
                receipts.append(_normalize_offline(header, detail, purchased_at))

            online = await _tecom_rpc(client, headers, "OrderHeadsList", {"forms": [1, 4], "limit": 50, "offset": 0})
            for head in (online or []):
                purchased_at = _parse_dt(head["createdDate"])
                if since and purchased_at < since:
                    continue
                detail = await _tecom_rpc(client, headers, "GetOrderDetail", {"orderId": head["id"]})
                receipts.append(_normalize_online(head, detail, purchased_at))

        return receipts


async def _fetch_detail(client: httpx.AsyncClient, headers: dict, header: dict) -> dict:
    params = {
        "filialId": header["filialId"],
        "chequeId": header["chequeId"],
        "created": header["created"],
    }
    resp = await client.get(
        f"{BASE_URL}/2.0/chequeinfo?{urllib.parse.urlencode(params)}", headers=headers
    )
    resp.raise_for_status()
    return resp.json().get("chequeInfo") or {}


def _normalize_offline(header: dict, detail: dict, purchased_at: dt.datetime) -> NormalizedReceipt:
    lines = detail.get("chequeLines") or []
    items = [_normalize_item(line) for line in lines]

    return NormalizedReceipt(
        external_id=str(header["chequeId"]),
        purchased_at=purchased_at,
        total_amount=float(header.get("sumReg") or 0),
        shop_name=header.get("filialName"),
        shop_address=header.get("cityName"),
        payment_type=header.get("payTypeName"),
        channel="offline",
        items=items,
        raw={"header": header, "detail": detail},
    )


async def _tecom_rpc(client: httpx.AsyncClient, headers: dict, method: str, data: dict):
    resp = await client.post(TECOM_URL, headers=headers, json={"Method": method, "data": data})
    resp.raise_for_status()
    payload = resp.json()
    if payload.get("error") or payload.get("eComError"):
        raise AdapterError(f"Fozzy: {method} — {payload.get('error') or payload.get('eComError')}")
    return payload.get("data")


def _normalize_online(head: dict, detail: dict, purchased_at: dt.datetime) -> NormalizedReceipt:
    items = [
        NormalizedItem(
            name=it.get("name", "").strip(),
            quantity=float(it.get("countActual") or 0),
            unit=it.get("unit"),
            unit_price=float(it.get("price") or 0),
            total_price=float(it.get("sumActual") or 0),
        )
        for it in (detail.get("items") or [])
        if it.get("lineStateId") != 1 and (it.get("countActual") or 0) > 0
    ]

    return NormalizedReceipt(
        external_id=f"online:{head['id']}",
        purchased_at=purchased_at,
        total_amount=float(head.get("sumActual") or 0),
        shop_name=head.get("filialName"),
        shop_address=head.get("deliveryAddress"),
        payment_type=head.get("paymentTypeName"),
        channel="online",
        items=items,
        total_discount=abs(float(head.get("sumActualDiscount") or 0)),
        raw={"head": head, "detail": detail},
    )


def _normalize_item(line: dict) -> NormalizedItem:
    lager = line.get("lagerInfo") or {}
    quantity = float(line.get("amount") or 1)
    total_price = float(line.get("sumReg") or 0)

    # The API doesn't send a per-unit price on the cheque line itself — derive it
    # from what was actually charged (total/qty), falling back to the catalog price
    # (lagerInfo.price) only if quantity is missing/zero and division isn't possible.
    unit_price = round(total_price / quantity, 2) if quantity else lager.get("price")

    return NormalizedItem(
        name=lager.get("name", "").strip(),
        quantity=quantity,
        unit_price=unit_price,
        total_price=total_price,
        discount=float(line.get("sumDiscount") or 0),
        category=(lager.get("category") or {}).get("name"),
    )


async def _exchange(client: httpx.AsyncClient, grant_data: dict) -> AuthResult:
    """POST /connect/token with either an auth_token or a refresh_token grant —
    same request/response shape either way, just different body fields."""
    resp = await client.post(
        f"{AUTH_BASE}/connect/token",
        headers={"Authorization": CONNECT_BASIC_AUTH, "Content-Type": "application/x-www-form-urlencoded"},
        data={"client_id": "fozzy_mobile_android", **grant_data},
    )
    if resp.status_code != 200:
        raise AdapterError(f"Fozzy: не вдалось обміняти токен ({resp.status_code}): {resp.text[:200]}")
    payload = resp.json()
    expires_at = dt.datetime.now(dt.timezone.utc) + dt.timedelta(seconds=payload.get("expires_in", 3600))
    return AuthResult(
        access_token=payload["access_token"],
        refresh_token=payload.get("refresh_token"),
        expires_at=expires_at,
    )
